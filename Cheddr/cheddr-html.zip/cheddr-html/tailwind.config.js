/** @type {import('tailwindcss').Config} */
module.exports = {
  // NOTE: Update this to include the paths to all of your component files.
  content: ["./app/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors:{
        "cheddr-white":"#fff",
        "cheddr-dark":"#070707",
        "cheddr-page-bg":"#0C0C0C",
        "cheddr-dark-black":"#0B0B0B",
        "cheddr-black":"#1C1C1C",
        "cheddr-yellow":"#FFD93F",
        "cheddr-pink":"#DC00FF",
        "cheddr-grey":"#6A6868",
        "cheddr-green":"#17DBA8",
      },
      fontFamily: {
        MonumentBlack: ["MonumentExtendedBlack"],
        MonumentHeavy: ["MonumentExtendedHeavy"],
        Circular400: ["CircularLLBook"],
        Circular500: ["CircularMedium"],
        Circular700: ["CircularBold"],
      }
    },
  },
  plugins: [],
}