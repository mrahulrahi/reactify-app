import { ThemeProvider, useTheme } from "./contexts/ThemeContext"; 
import { Stack } from "expo-router";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import "../global.css";


SplashScreen.preventAutoHideAsync();

function LayoutContent() {
  const [fontsLoaded] = useFonts({
    MonumentExtendedBlack: require("../assets/fonts/MonumentExtended-Black.ttf"),
    MonumentExtendedHeavy: require("../assets/fonts/MonumentExtended-Heavy.ttf"),
    CircularLLBook: require("../assets/fonts/Circular-Book.otf"),
    CircularMedium: require("../assets/fonts/Circular-Medium.otf"),
    CircularBold: require("../assets/fonts/Circular-Bold.otf"),
  });

  const { theme } = useTheme(); // Get theme from context

  useEffect(() => {
    if (fontsLoaded) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) return null;

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: {
          backgroundColor: theme === "yellow" ? "#FFD93F" : "#32CD32", 
        },
      }}
    />
  );
}

export default function Layout() {
  return (
    <ThemeProvider>
      <LayoutContent />
    </ThemeProvider>
  );
}
