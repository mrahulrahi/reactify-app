import { useEffect, useRef, useState } from "react";
import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { View, Text, Pressable, FlatList, Dimensions } from "react-native";

import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { useTheme } from "../contexts/ThemeContext"; 

const { width } = Dimensions.get("window");

const slides = [
  {
    id: "1",
    text: "WELCOME TO SPORTS BETTING 2.0",
    image: require("../../assets/images/player-1.jpg"),
  },
  {
    id: "2",
    text: "FAST BETS, FASTER PAYOUTS",
    image: require("../../assets/images/player-2.jpg"),
  },
  {
    id: "3",
    text: "BIG PLAYS, HUGE WINS, ZERO FRICTION",
    image: require("../../assets/images/player-3.jpg"),
  },
  { id: "4", image: require("../../assets/images/player-4.jpg"), button: true },
];

export default function OnboardingScreen() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef(null);
  const router = useRouter();
  const { theme } = useTheme();

  const buttonColor = theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green";
  const textColor = theme === "yellow" ? "text-cheddr-white" : "text-cheddr-white";

  useEffect(() => {
    const interval = setInterval(() => {
      let nextIndex = currentIndex + 1;
      if (nextIndex >= slides.length) {
        nextIndex = 0; 
      }
      setCurrentIndex(nextIndex);
      flatListRef.current?.scrollToOffset({ offset: nextIndex * width, animated: true });
    }, 3000); 

    return () => clearInterval(interval); 
  }, [currentIndex]);
  
  // useEffect(() => {
  //   if (currentIndex >= slides.length - 1) return; 
  
  //   const interval = setInterval(() => {
  //     setCurrentIndex(prevIndex => {
  //       const nextIndex = prevIndex + 1;
  //       flatListRef.current?.scrollToOffset({ offset: nextIndex * width, animated: true });
  //       return nextIndex;
  //     });
  //   }, 3000);
  
  //   return () => clearInterval(interval);
  // }, [currentIndex]);
  

  return (
    <SafeAreaProvider>
      <SafeAreaView className="flex-1">
        <View className="flex-1 bg-cheddr-dark">
          <FlatList
            ref={flatListRef}
            data={slides}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={(event) => {
              const index = Math.round(
                event.nativeEvent.contentOffset.x / width
              );
              setCurrentIndex(index);
            }}
            keyExtractor={(item) => item.id}
            renderItem={({ item, index }) => (
              <View className="w-screen flex-col h-[90svh]">
                <View className="w-full grow items-center pt-8 justify-center bg-cheddr-dark">
                  <Image
                    source={item.image}
                    className="w-full h-full"
                    contentFit="contain"
                    style={{
                      flex: 1,
                      width: "100%",
                      height: "100%",
                    }}
                  />
                </View>

                <View
                  className={`w-full mx-auto pt-6 items-center ${
                    index === 0 ? "max-w-[305px]" : "max-w-[355px]"
                  }`}
                >
                  <Text
                    className={`font-MonumentHeavy text-[33px] leading-[87%] ${textColor} tracking-[-0.02em] text-center`}
                  >
                    {item.text}
                  </Text>
                  {item.button && (
                    <Pressable
                      className={`${buttonColor} px-[36px] min-w-[196px] text-center py-[15px] rounded-[27px]`}
                      onPress={() => router.push("dashboard")}
                    >
                      <Text className="text-cheddr-dark-black font-Circular400 text-[17px] text-center">
                        Play Now
                      </Text>
                    </Pressable>
                  )}
                </View>
              </View>
            )}
          />

          <View className="flex-row items-center justify-center py-[5vh]">
            {slides.map((_, index) => (
              <View
                key={index}
                className={`h-[2px] w-[30px] mx-[4px] rounded-full ${
                  currentIndex === index
                    ? "bg-cheddr-white w-4"
                    : "bg-cheddr-white/25"
                }`}
              />
            ))}
          </View>
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
