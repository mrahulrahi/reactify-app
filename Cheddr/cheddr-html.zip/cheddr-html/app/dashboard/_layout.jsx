import { Tabs } from "expo-router";
import { useTheme } from "../contexts/ThemeContext";
import IconWithDot from "../components/tabIconWithDots"


const myPicksYellowActive = require("../../assets/images/my-picks-yellow-active.png");
const myPicksYellowInactive = require("../../assets/images/my-picks-yellow.png");
const dashboardYellowActive = require("../../assets/images/dashboard-yellow-active.png");
const dashboardYellowInactive = require("../../assets/images/dashboard-yellow.png");
const profileYellowActive = require("../../assets/images/profile-yellow-active.png");
const profileYellowInactive = require("../../assets/images/profile-yellow.png");

const myPicksGreenActive = require("../../assets/images/my-picks-green-active.png");
const myPicksGreenInactive = require("../../assets/images/my-picks-yellow.png"); 
const dashboardGreenActive = require("../../assets/images/dashboard-green-active.png");
const dashboardGreenInactive = require("../../assets/images/dashboard-yellow.png"); 
const profileGreenActive = require("../../assets/images/profile-green-active.png");
const profileGreenInactive = require("../../assets/images/profile-yellow.png"); 

export default function RootLayout() {
  const { theme } = useTheme();

  const getIcon = (yellowActive, yellowInactive, greenActive, greenInactive, focused) =>
    theme === "yellow" ? (focused ? yellowActive : yellowInactive) : (focused ? greenActive : greenInactive);

  return (
    <Tabs
      initialRouteName="stats"
      screenOptions={{
        tabBarShowLabel: false, 
        tabBarActiveTintColor: theme === "yellow" ? "#FFD93F" : "#4CAF50",
        tabBarInactiveTintColor: "#fff",
        headerShown: false,
        tabBarStyle: {
          width: "100%",
          backgroundColor: theme === "yellow" ? "#0B0B0B" : "#0B0B0B",
          borderTopWidth: 1,
          borderColor:'#2B2B2B',
          height: 111,
          paddingTop: 14,
        },
        tabBarBadgeStyle: {
          color: "#fff",
          backgroundColor: theme === "yellow" ? "#DC00FF" : "#DC00FF",
        },
      }}
    >
      <Tabs.Screen
        name="my-picks"
        options={{
          tabBarBadge: 3,
          tabBarIcon: ({ focused }) => (
            <IconWithDot
              icon={getIcon(myPicksYellowActive, myPicksYellowInactive, myPicksGreenActive, myPicksGreenInactive, focused)}
              focused={focused}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="stats"
        options={{
          tabBarIcon: ({ focused }) => (
            <IconWithDot
              icon={getIcon(dashboardYellowActive, dashboardYellowInactive, dashboardGreenActive, dashboardGreenInactive, focused)}
              focused={focused}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="profile/page"
        options={{
          tabBarIcon: ({ focused }) => (
            <IconWithDot
              icon={getIcon(profileYellowActive, profileYellowInactive, profileGreenActive, profileGreenInactive, focused)}
              focused={focused}
            />
          ),
        }}
      />
    </Tabs>

  );
}

