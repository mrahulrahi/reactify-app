import React, { useState } from "react";
import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { ScrollView, View, Text, Pressable } from "react-native";
import BetSlipModal from "../../components/betSlipModal";
import PickSubmittedModal from '../../components/pickSubmittedModal';


export default function HomeScreen() {
  const [isModalVisible, setModalVisible] = useState(false);
  const [isSubmittedModalVisible, setSubmittedModalVisible] = useState(false);

  return (
    <SafeAreaProvider>
      <SafeAreaView className="flex-1 bg-cheddr-page-bg">
        <ScrollView className="grow px-[20px] ">
          <View className="mb-5"><Text className="text-cheddr-yellow">Home Content</Text></View>


          <View className="w-full max-w-[200px] mx-auto flex-col gap-4 mt-5">
            <Pressable className="p-4 rounded-full bg-cheddr-yellow flex items-center" onPress={() => setModalVisible(true)}><Text className="text-cheddr-dark-black">Open Bet Slip</Text></Pressable>
            <Pressable className="p-4 rounded-full bg-cheddr-yellow flex items-center" onPress={() => setSubmittedModalVisible(true)}><Text className="text-cheddr-dark-black">Pick submitted</Text></Pressable>
          </View>
          
          <BetSlipModal isVisible={isModalVisible} onClose={() => setModalVisible(false)} />
          <PickSubmittedModal isVisible={isSubmittedModalVisible} onClose={() => setSubmittedModalVisible(false)} />


        </ScrollView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
