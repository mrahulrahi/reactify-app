import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { ScrollView, View, Text } from "react-native";
import BettingCard from "../../components/BettingCard";

export default function InPlayScreen() {
  const games = [
    {
      status: "Q4",
      time: "10:20",
      teams: [
        {
          name: "Lindenwood Lions",
          score: 64,
          bets: [
            { value: "-560" },
            { value: "+6", sub: "-115.0" },
            { value: "120", sub: "-90.5" }
          ]
        },
        {
          name: "Little RocksTro...",
          score: 64,
          bets: [
            { value: "+380" },
            { value: "+14.5", sub: "-120.5" },
            { value: "154", sub: "-340" }
          ]
        }
      ]
    },
    {
      status: "STARTING SOON",
      time: "12:30",
      teams: [
        {
          name: "Central CT",
          score: 34,
          bets: [
            { value: "230" },
            { value: "+34", sub: "-95.0" },
            { value: "120", sub: "-90.5" }
          ]
        },
        {
          name: "NC State",
          score: 23,
          bets: [
            { value: "+380" },
            { value: "+10.5", sub: "-113" },
            { value: "120", sub: "-150" }
          ]
        }
      ]
    }
  ];
  return (
    <SafeAreaProvider>
        <SafeAreaView className="flex-1 bg-cheddr-page-bg">
          <ScrollView className="grow px-[20px] ">
            <View className="border-b-[0.52px] border-[#363636] pt-4 pb-[30px]"><Text className="text-[16px] font-Circular400 text-cheddr-white">Today</Text></View>
            
            {games.map((game, index) => (
              <BettingCard key={index} status={game.status} time={game.time} teams={game.teams} />
            ))}
  
          </ScrollView>
        </SafeAreaView>
      </SafeAreaProvider>
  );
}
