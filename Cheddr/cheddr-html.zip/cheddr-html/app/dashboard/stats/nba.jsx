import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { ScrollView, View, Text } from "react-native";

export default function NBAScreen() {
  return (
    <SafeAreaProvider>
      <SafeAreaView className="flex-1 bg-cheddr-page-bg">
        <ScrollView className="grow px-[20px] ">
          <View><Text className="text-cheddr-yellow">NBA Content</Text></View>
        </ScrollView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
