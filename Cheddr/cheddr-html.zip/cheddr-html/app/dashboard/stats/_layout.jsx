import React from "react";
import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import { View, Text } from "react-native";
import { useTheme } from "../../contexts/ThemeContext";
import { Image } from "react-native";
import HomeScreen from "./home";
import InPlayScreen from "./in-play";
import NBAScreen from "./nba";
import NFLScreen from "./nfl";
import MLBScreen from "./mlb";


const icons = {
  green: {
    Home: require("../../../assets/images/home-yellow.png"),
    HomeActive: require("../../../assets/images/home-green-active.png"),

    inPlay: require("../../../assets/images/in-play.png"),
    inPlayActive: require("../../../assets/images/in-play-green-active.png"),

    nba: require("../../../assets/images/nba.png"),
    nbaActive: require("../../../assets/images/nba-active.png"),

    nfl: require("../../../assets/images/nfl.png"),
    nflActive: require("../../../assets/images/nfl-active.png"),

    mlb: require("../../../assets/images/mlb.png"),
    mlbActive: require("../../../assets/images/mlb-active.png"),
  },
  yellow: {
    Home: require("../../../assets/images/home-yellow.png"),
    HomeActive: require("../../../assets/images/home-yellow-active.png"),

    inPlay: require("../../../assets/images/in-play.png"),    
    inPlayActive: require("../../../assets/images/in-play-yellow-active.png"),

    nba: require("../../../assets/images/nba.png"),
    nbaActive: require("../../../assets/images/nba-active.png"),

    nfl: require("../../../assets/images/nfl.png"),
    nflActive: require("../../../assets/images/nfl-active.png"),

    mlb: require("../../../assets/images/mlb.png"),
    mlbActive: require("../../../assets/images/mlb-active.png"),
  },
};

// Define background colors for themes
const themeColors = {
  green: {
    background: "#0C0C0C",
    active: "#0e352b", 
  },
  yellow: {
    background: "#0C0C0C", 
    active: "#3c340f",
  },
};

const Tab = createMaterialTopTabNavigator();

export default function StatsScreen() {
  const { theme } = useTheme();
  const themeMode = icons[theme] || icons.green;
  const themeColor = themeColors[theme] || themeColors.green;

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1 }}>
        <View className="flex-1 bg-cheddr-page-bg">

          <View className="w-full flex-row items-center justify-between p-5">
            <View><Text className="font-MonumentHeavy text-cheddr-white text-[31px] leading-tight">DASH</Text></View>
            <View className={`flex-row items-center rounded-[20px] gap-[34px] pr-[2px] py-[2px] pl-[12px] overflow-hidden ${theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green"}`} style={{borderRadius: 20}}>                  
              <Text className="text-cheddr-page-bg text-[18px] font-Circular400">$1208</Text>
              <Image 
              source={
                theme === "yellow"
                  ? require("../../../assets/images/crown-yellow-icon.png")
                  : require("../../../assets/images/crown-green-icon.png")
              }
              style={{ width: 31, height: 31}} contentFit="contain" />
            </View>
          </View>

          <Tab.Navigator
            screenOptions={({ route }) => ({
              tabBarStyle: {
                backgroundColor: themeColor.background, 
                elevation: 0,
              },
              tabBarIndicatorStyle: {
                backgroundColor: "transparent", 
              },
              tabBarLabelStyle: {
                fontSize: 12,
                marginTop: 10,
                color: "#6A6868",
              },
              tabBarItemStyle: {
                alignItems: "center",
                justifyContent: "center",
              },
              tabBarIcon: ({ focused }) => {
                let iconSource;
                let showBadge = route.name === "NFL";
                let badgeCount = 3;

                switch (route.name) {
                  case "Home":
                    iconSource = focused
                      ? themeMode.HomeActive
                      : themeMode.Home;
                    break;
                  case "In Play":
                    iconSource = focused
                      ? themeMode.inPlayActive
                      : themeMode.inPlay;
                    break;
                  case "NBA":
                    // iconSource = themeMode.nba;
                    iconSource = focused ? themeMode.nbaActive : themeMode.nba;
                    break;
                  case "NFL":
                    iconSource = focused ? themeMode.nflActive : themeMode.nfl;
                    break;
                  case "MLB":
                    iconSource = focused ? themeMode.mlbActive : themeMode.mlb;
                    break;
                }

                return (
                  <View
                  style={{
                    width: 60,
                    height: 60,
                    borderRadius: 30, 
                    backgroundColor: focused ? themeColor.active : "#1C1C1C",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                  >
                    <Image
                      source={iconSource}
                      style={{ width: 28, height: 28 }}
                      resizeMode="contain"
                    />
                    {showBadge && badgeCount > 0 && (
                      <View
                        style={{
                          position: "absolute",
                          top: 8,
                          right:10,
                          backgroundColor: "#DC00FF",
                          width: 16,
                          height: 16,
                          borderRadius: 9,
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <Text
                          style={{
                            color: "#fff",
                            fontSize: 10,
                            fontWeight:"700",
                          }}
                        >
                          {badgeCount}
                        </Text>
                      </View>
                    )}
                  </View>
                );
              },
            })}
          >
            <Tab.Screen name="Home" component={HomeScreen} />
            <Tab.Screen name="In Play" component={InPlayScreen} />
            <Tab.Screen name="NBA" component={NBAScreen} />
            <Tab.Screen name="NFL" component={NFLScreen} />
            <Tab.Screen name="MLB" component={MLBScreen} />
          </Tab.Navigator>
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
