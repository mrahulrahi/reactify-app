import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { ScrollView, View, Text } from "react-native";

export default function MlbScreen() {
  return (
    <SafeAreaProvider>
      <SafeAreaView className="flex-1 bg-cheddr-page-bg">
        <ScrollView className="grow px-[20px] ">
          <View><Text className="text-cheddr-yellow">MLB Content</Text></View>
        </ScrollView>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
