import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { View, Text } from "react-native";
import { useTheme } from "../../contexts/ThemeContext"; 

export default function ProfileScreen() {
  const { theme } = useTheme(); 
  return (
    <SafeAreaProvider>
        <SafeAreaView className="flex-1 ">
          <View className="flex-1 bg-cheddr-dark items-center justify-center">
            <Text className={`text-[20px] font-bold ${theme === "yellow" ? "text-yellow-500" : "text-green-500"}`}>Profile Screen</Text>
          </View>
        </SafeAreaView>
    </SafeAreaProvider>
    
  );
}
