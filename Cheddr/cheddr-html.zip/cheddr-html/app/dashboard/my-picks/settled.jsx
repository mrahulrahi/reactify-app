import { View, Text, ScrollView } from "react-native";
import BetCard from "../../components/BetCard";


const bets = [
  {
    team: "New York Knicks",
    odds: "-590",
    matchup: "New York Knicks vs Brooklyn Nets",
    risk: "+1000",
    payout: "+1000",
    pickId: "4424636",
    date: "Jan 20 2025, 4:30PM",
    status: "Win",
    timeAgo: "2 DAYS AGO",
  },
  {
    team: "Detroit Lions",
    odds: "-320",
    matchup: "Detroit Lions vs Minnesota Vikings",
    risk: "+2500",
    payout: "+2500",
    pickId: "4424637",
    date: "Jan 19 2025, 2:45PM",
    status: "Win",
    timeAgo: "3 DAYS AGO",
  },
];
export default function SettledPicks() {
  return (
    <View className="flex-1 bg-cheddr-dark">
      {/* <Text className="text-white text-lg">No settled picks yet.</Text> */}
      <ScrollView className="flex-1 pt-[65px] p-5">
        {bets.map((bet, index) => (
          <View key={bet.pickId} className={index !== bets.length - 1 ? "mb-4" : ""}>
            <BetCard {...bet} />
          </View>
        ))}
    </ScrollView>
    </View>
  );
}
