import { View, Text } from "react-native";
import { SafeAreaView, SafeAreaProvider } from "react-native-safe-area-context";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import ActiveScreen from "./active";
import SettledScreen from "./settled";
import CustomTabBar from "../../components/CustomTabsBar";
import { useTheme } from "../../contexts/ThemeContext";
import { Image } from "react-native";

const Tab = createMaterialTopTabNavigator();
export default function DashboardLayout() {
    const { theme } = useTheme();
    
  return (
    <SafeAreaProvider>
      <SafeAreaView  style={{ flex: 1 }}>
        <View className="bg-cheddr-page-bg" style={{ flex: 1 }}>  
          <View className="w-full flex-row items-center justify-between p-5">
            <View><Text className="font-MonumentHeavy text-cheddr-white text-[31px] leading-tight">MY PICKS</Text></View>
            <View className={`flex-row items-center rounded-[20px] gap-[34px] pr-[2px] py-[2px] pl-[12px] overflow-hidden ${theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green"}`} style={{borderRadius: 20}}>                  
              <Text className="text-cheddr-page-bg text-[18px] font-Circular400">$1208</Text>
              <Image 
              source={
                theme === "yellow"
                  ? require("../../../assets/images/crown-yellow-icon.png")
                  : require("../../../assets/images/crown-green-icon.png")
              }
              style={{ width: 31, height: 31}} contentFit="contain" />
            </View>
          </View>       
          <Tab.Navigator  tabBar={(props) => <CustomTabBar {...props} />}>
            <Tab.Screen name="Active" component={ActiveScreen} />
            <Tab.Screen name="Settled" component={SettledScreen} />
          </Tab.Navigator>
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
