import { View, Text } from "react-native";

export default function ActivePicks() {
  return (
    <View className="flex-1 items-center justify-center bg-cheddr-dark">
      <Text className="text-white text-lg">No active picks yet.</Text>
    </View>
  );
}
