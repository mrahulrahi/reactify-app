import { View, Text, Pressable  } from "react-native";
import { Image } from "expo-image";
import { useTheme } from "../contexts/ThemeContext";
import { useState } from "react";

export default function BettingCard({ status, time, teams }) {
    const { theme } = useTheme();
  
    const isStartingSoon = status === "STARTING SOON";

    const [selectedBet, setSelectedBet] = useState(null);

    return (
        <View className="pt-[8px] pb-4 border-b-[0.52px] border-[#363636]">
            <View className="flex-row">
                <View>
                    <View className="w-[160px] pr-[15px] items-start">
                        <View className="flex-row">
                            <View className={`py-[4px] px-[6px] rounded-l-[5px] ${isStartingSoon ? "bg-[#555555]" : theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green"}`}>
                                <Text className="text-[11px] font-Circular400 text-cheddr-page-bg">{status}</Text>
                            </View>
                            <View className={`py-[4px] px-[6px] rounded-r-[5px] ${isStartingSoon ? "bg-[#464646]" : theme === "yellow" ? "bg-[#cbab1c]" : "bg-[#15b289]"}`}>
                                <Text className="text-[11px] font-Circular400 text-cheddr-page-bg">{time}</Text>
                            </View>
                        </View>
                    </View>
                </View>
                <View className="flex-row flex-1">
                    <View className="flex-1 items-center"><Text className="text-[10px] text-[#606060]">MONEYLINE</Text></View>
                    <View className="flex-1 items-center"><Text className="text-[10px] text-[#606060]">SPREAD</Text></View>
                    <View className="flex-1 items-center"><Text className="text-[10px] text-[#606060]">TOTAL</Text></View>
                </View>
            </View>

            {/* <View className="gap-[9px] mt-8">
                {teams.map((team, index) => (
                    <View key={index} className="flex-row">
                        <View className="w-[160px] pr-[15px] flex-row items-center justify-between">
                            <View><Text className="text-[12px] font-Circular400 text-cheddr-white max-w-[120px] line-clamp-1">{team.name}</Text></View>
                            <View><Text className="text-[17px] font-Circular400 text-cheddr-white">{team.score}</Text></View>
                        </View>
                        <View className="flex-row flex-1 justify-between">
                            {team.bets.map((bet, betIndex) => (
                                <View key={betIndex} className="flex-1 items-center">
                                    <View className="rounded-full w-[50px] h-[50px] bg-[#1C1C1C] border border-transparent text-center items-center justify-center">
                                        <View><Text className="text-[#8E8E8E] text-[13px] font-Circular400">{bet.value}</Text></View>
                                        {bet.sub && <View><Text className={`text-[13px] font-Circular400 ${theme === "yellow" ? "text-cheddr-yellow" : "text-cheddr-green"}`}>{bet.sub}</Text></View>}
                                    </View>
                                </View>
                            ))}
                        </View>  
                    </View>
                ))}
            </View> */}
            <View className="gap-[9px] mt-8">
                {teams.map((team, teamIndex) => (
                    <View key={teamIndex} className="flex-row">
                    <View className="w-[160px] pr-[15px] flex-row items-center justify-between">
                        <View>
                        <Text className="text-[12px] font-Circular400 text-cheddr-white max-w-[120px] line-clamp-1">
                            {team.name}
                        </Text>
                        </View>
                        <View>
                        <Text className="text-[17px] font-Circular400 text-cheddr-white">{team.score}</Text>
                        </View>
                    </View>

                    <View className="flex-row flex-1 justify-between">
                        {team.bets.map((bet, betIndex) => {
                        const betKey = `${teamIndex}-${betIndex}`; // Unique key per team & bet

                        return (
                            <View key={betKey} className="flex-1 items-center">
                            <Pressable
                                onPress={() => setSelectedBet(selectedBet === betKey ? null : betKey)} // Toggle selection
                                className={`rounded-full w-[50px] h-[50px] border text-center items-center justify-center 
                                    ${selectedBet === betKey ? (theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green") : "bg-[#1C1C1C]"}`}
                                >
                                <Text className={`text-[13px] font-Circular400
                                    ${selectedBet === betKey ? "text-[#1C1C1C]" : "text-[#8E8E8E]"}`}>{bet.value}
                                </Text>
                                {bet.sub && (

                                    <Text className={`text-[13px] font-Circular400 ${
                                        selectedBet === betKey
                                        ? "text-[#1C1C1C]" // Dark text if selected
                                        : theme === "yellow"
                                        ? "text-cheddr-yellow" // Yellow theme when not selected
                                        : "text-cheddr-green" // Green theme when not selected
                                    }`}>
                                    {bet.sub}
                                </Text>

                                )}
                            </Pressable>
                            </View>
                        );
                        })}
                    </View>
                    </View>
                ))}
            </View>

            <View className="flex-row items-center justify-between mt-6">
                <Image style={{width:22,height:22}} contentFit="contain" source={require("../../assets/images/nhl-logo.png")} />
                <View className="bg-cheddr-black rounded-[5px] overflow-hidden px-[6px] py-[5px]"><Text className="text-[#8E8E8E] text-[11px] leading-tight">INFO</Text></View>
            </View>
        </View>
    );
}
