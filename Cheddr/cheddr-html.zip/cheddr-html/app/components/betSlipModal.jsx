import React from "react";
import { View, Text, Pressable, TextInput } from "react-native";
import Modal from "react-native-modal";
import { useTheme } from "../contexts/ThemeContext";
import { Image } from "expo-image";

const BetSlipModal = ({ isVisible, onClose }) => {
  const { theme } = useTheme();

  const textColor = theme === "yellow" ? "text-cheddr-yellow" : "text-cheddr-green";

  const coinImage =
    theme === "yellow"
      ? require("../../assets/images/yellow-coin.png")
      : require("../../assets/images/green-coin.png");

    const PayOutImage =
      theme === "yellow"
        ? require("../../assets/images/yellow-coin.png")
        : require("../../assets/images/green-coin.png");

    const RiskImage =
        theme === "yellow"
          ? require("../../assets/images/risk-icon.png")
          : require("../../assets/images/green-dark-coin.png");

  return (
    <Modal isVisible={isVisible} onBackdropPress={onClose} style={{ margin: 0 }}>
      <View
        className={`absolute bottom-0 w-full p-[30px] rounded-t-[35px] ${
          theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green"
        }`}
      >
        <View className="flex-row relative pr-8">
          <View className="flex-1">
            <Text className="text-[31px] text-cheddr-dark-black font-MonumentHeavy">
              BET SLIP
            </Text>
          </View>
          <Pressable onPress={onClose} className="flex items-center justify-center w-6 h-6 absolute right-[2px] top-0">
            <Image
              style={{ width: 14, height: 8 }}
              contentFit="contain"
              source={require("../../assets/images/arrow-down.png")}
            />
          </Pressable>
        </View>
        
        <View className="flex-row items-center justify-between gap-4 mt-[35px]">
            <View className="flex-1">
                <View><Text className="font-Circular400 text-[17px] text-cheddr-dark-black">Balance: 1208 Rally Coins</Text></View>
            </View>
            <View>
                <View className="w-[69px] h-[36px] relative bg-cheddr-dark-black rounder-full overflow-hidden" style={{borderRadius:100}}>
                    <View className="W-[32px] h-[32px] absolute top-1/2 -translate-y-1/2 right-[2px]">
                        <Image source={coinImage} style={{ width: 32, height: 32 }} contentFit="contain" />
                    </View>
                </View>
            </View>
        </View>

        <View className="py-[24px] border-y mt-[18px]">
            <View className="flex-row justify-between">
                <View><Text className="font-Circular700 text-[22px] leading-none text-cheddr-dark-black">New York Knicks</Text></View>
                <View className="flex-row items-center gap-4">
                    <View><Text className="font-Circular700 text-[22px] leading-none text-cheddr-dark-black">-590</Text></View>
                    <Pressable className="w-6 h-6 flex items-center justify-center">
                        <Image style={{width:12, height:12}} contentFit="contain" source={require("../../assets/images/close-icon.png")} />
                    </Pressable>
                </View>
            </View>
            <View className="mt-[7px]"><Text className="font-Circular500 leading-none text-[13px] uppercase text-cheddr-dark-black">MONEYLINE</Text></View>
            <View className="mt-[24px]"><Text className="font-Circular400 text-[17px] leading-none text-cheddr-dark-black">New York Knicks vs Brooklyn Nets</Text></View>
        </View>

        <View className="mt-[40px]">
            <View className="flex-row gap-2">
                <View className="flex-1">
                    <View className="mb-2.5"><Text className="font-Circular400 text-[17px] leading-none text-cheddr-dark-black">Risk</Text></View>
                    <View className="flex items-center w-full">
                        <View className="h-[54px] w-full relative flex-row items-center rounded-full border border-cheddr-dark-black/60">
                            <TextInput
                                className="flex-grow h-[45px] pt-1 px-4 font-Circular400 text-[13px] leading-none"
                                value="1000"
                                keyboardType="numeric"
                            />
                            <View className="w-[32px] h-[32px] absolute right-[10px] top-1/2 -translate-y-1/2">
                                <Image 
                                    source={RiskImage}
                                    style={{ width: 32, height: 32, opacity:0.6 }}
                                    contentFit="contain"
                                />
                            </View>
                        </View>
                    </View>
                </View>
                <View className="flex-1">
                    <View className="mb-2.5"><Text className="font-Circular400 text-[17px] leading-none text-cheddr-dark-black">Payout</Text></View>
                    <View className="flex items-center w-full">
                        <View className="h-[54px] w-full relative flex-row items-center bg-cheddr-dark-black rounded-full">
                            <TextInput
                                className="flex-grow h-[45px] pt-1 px-4 font-Circular400 text-cheddr-white leading-none text-[13px]"
                                value="2000"
                                keyboardType="numeric"
                            />
                            <View className="w-[32px] h-[32px] absolute right-[15px] top-1/2 -translate-y-1/2">
                                <Image
                                    source={PayOutImage}
                                    style={{ width: 32, height: 32, marginLeft: 8 }}
                                    contentFit="contain"
                                />
                            </View>
                        </View>
                    </View>
                </View>
            </View>
            <View className="flex-row gap-2 mt-[13px]">
                <Pressable className="h-[52px] bg-cheddr-dark-black/25 flex-1 flex items-center justify-center rounded-full"><Text className="font-Circular400 text-[13px] leading-none text-cheddr-white">+1000</Text></Pressable>
                <Pressable className="h-[52px] bg-cheddr-dark-black/25 flex-1 flex items-center justify-center rounded-full"><Text className="font-Circular400 text-[13px] leading-none text-cheddr-white">+1000</Text></Pressable>
                <Pressable className="h-[52px] bg-cheddr-dark-black/25 flex-1 flex items-center justify-center rounded-full"><Text className="font-Circular400 text-[13px] leading-none text-cheddr-white">+1000</Text></Pressable>
                <Pressable className="h-[52px] bg-cheddr-dark-black/25 flex-1 flex items-center justify-center rounded-full"><Text className="font-Circular400 text-[13px] leading-none text-cheddr-white">+1000</Text></Pressable>
            </View>
        </View>

        <View className="w-full items-center justify-center mt-[64px]">
            <View className="items-center w-full max-w-[170px]">
                <Pressable className="bg-cheddr-dark-black rounded-full h-[54px] p-[15px] min-w-full flex items-center justify-center">
                    <Text className= {`${textColor} font-Circular400 text-[17px] leading-none`}>Submit Bet</Text>
                </Pressable>
            </View>
            <View className="mt-[42px]">
                <Text className="text-[#1F2023] text-[14px] text-center leading-tight font-Circular400">1,000 counts towards your play through</Text>
            </View>
        </View>

      </View>
    </Modal>
  );
};

export default BetSlipModal;
