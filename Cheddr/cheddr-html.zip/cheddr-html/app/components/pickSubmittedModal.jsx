import React from "react";
import { View, Text, Pressable, TextInput } from "react-native";
import Modal from "react-native-modal";
import { useTheme } from "../contexts/ThemeContext";
import { Image } from "expo-image";

const PickSubmittedModal = ({ isVisible, onClose }) => {
  const { theme } = useTheme();

  const textColor = theme === "yellow" ? "text-cheddr-yellow" : "text-cheddr-green";


  

  return (
    <Modal isVisible={isVisible} onBackdropPress={onClose} style={{ margin: 0 }}>

      
      <View
        className={`absolute bottom-0 w-full p-[30px] pb-[50px] rounded-t-[35px] ${
          theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green"
        }`}
      >

        <View className="absolute flex-1 left-0 right-0  top-[-60px] items-center justify-center">
          <Pressable className="bg-[#1C1C1C] rounded-full px-[23px] py-[15px]"><Text className="text-[#8E8E8E] font-Circular400 text-[17px] leading-none">Share bet with friends</Text></Pressable>
        </View>

        <View className="flex-row relative pr-8">
          <View className="flex-1">
            <Text className="text-[31px] text-cheddr-dark-black font-MonumentHeavy">
                PICK SUBMITTED
            </Text>
          </View>
          <Pressable onPress={onClose} className="flex items-center justify-center w-6 h-6 absolute right-[2px] top-0">
            <Image
              style={{ width: 14, height: 8 }}
              contentFit="contain"
              source={require("../../assets/images/arrow-down.png")}
            />
          </Pressable>
        </View>
         
        <View className="flex-row mt-[49px]">
            <View className={`py-[4px] px-[6px] rounded-l-[5px] ${ theme === "yellow" ? "bg-cheddr-page-bg" : "bg-cheddr-page-bg"}`}>
                <Text className="text-[11px] font-Circular400 text-cheddr-white">NBA</Text>
            </View>
            <View className={`py-[4px] px-[6px] rounded-r-[5px] ${ theme === "yellow" ? "bg-[#3c3415]" : "bg-[#0d352a]"}`}>
                <Text className="text-[11px] font-Circular400 text-cheddr-white">TODAY AT 5:15</Text>
            </View>
        </View>

        <View className="py-[24px] border-t mt-[18px]">
            <View className="flex-row justify-between">
                <View><Text className="font-Circular700 text-[22px] leading-none text-cheddr-dark-black">New York Knicks</Text></View>
                <View className="flex-row items-center gap-4">
                    <View><Text className="font-Circular700 text-[22px] leading-none text-cheddr-dark-black">-590</Text></View>
                   
                </View>
            </View>
            <View className="mt-[7px]"><Text className="font-Circular500 leading-none text-[13px] uppercase text-cheddr-dark-black">POINT SPREAD</Text></View>
            <View className="mt-[24px]"><Text className="font-Circular400 text-[17px] leading-none text-cheddr-dark-black">New York Knicks vs Brooklyn Nets</Text></View>
        </View>

        <View className='w-full flex-row border-y border-[#525252]'>
            <View className='flex-1 items-center p-5 border-r border-[#525252]'>
                <View>
                    <View className='flex-row'>
                        <View><Text className='text-cheddr-dark-black font-Circular400 text-[16px]'>Risk</Text></View>
                        <View className='ml-[12px] mr-[10px]'><Image style={{width:22, height:22}} contentFit="contain" source={require("../../assets/images/crown-yellow-icon.png")} /></View>
                        <View><Text className='text-cheddr-dark-black font-Circular400 text-[16px]'>+1000</Text></View>
                    </View>
                </View>
            </View>
            <View className='flex-1 items-center p-5'>
                <View>
                    <View className='flex-row'>
                        <View><Text className='text-cheddr-dark-black font-Circular400 text-[16px]'>Payout</Text></View>
                        <View className='ml-[12px] mr-[10px]'><Image style={{width:22, height:22}} contentFit="contain" source={require("../../assets/images/crown-yellow-icon.png")} /></View>
                        <View><Text className='text-cheddr-dark-black font-Circular400 text-[16px]'>+1000</Text></View>
                    </View>
                </View>
            </View>
        </View>

        <View className="w-full items-center justify-center mt-[64px]">
            <View className="items-center w-full max-w-[170px]">
                <Pressable className="bg-cheddr-dark-black rounded-full h-[54px] p-[15px] min-w-full flex items-center justify-center">
                    <Text className= {`${textColor} font-Circular400 text-[17px] leading-tighter`}>Copy to Cheddr Cash</Text>
                </Pressable>
            </View>
        </View>

      </View>
    </Modal>
  );
};

export default PickSubmittedModal;
