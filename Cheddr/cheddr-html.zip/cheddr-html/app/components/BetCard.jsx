import { View, Text} from 'react-native';
import { Image } from 'expo-image';
import { useTheme } from "../contexts/ThemeContext";

const BetCard = ({ team, odds, matchup, risk, payout, pickId, date, status, timeAgo }) => {
    
    const { theme } = useTheme();
    const coinImage =
    theme === "yellow"
      ? require("../../assets/images/yellow-coin.png")
      : require("../../assets/images/green-coin.png");

  return (
    <View className='border border-[#525252] rounded-[10px]'>

        <View className='flex-1 pt-[18px] pb-[28px] px-5'>
            <View className='flex-row flex-1'>
                <View className='flex-1 mb-9'>
                    <View className='flex-row'>
                        <View className={`py-[4px] px-[6px] rounded-l-[5px] ${theme === "yellow" ? "bg-cheddr-yellow" : "bg-cheddr-green"}`}><Text className='font-Circular400 text-[11px] text-cheddr-page-bg tracking-[0.05em] uppercase'>{status}</Text></View>
                        <View className={`py-[4px] px-[6px] rounded-r-[5px] ${theme === "yellow" ? "bg-[#cbab1c]" : "bg-[#15b289]"}`}><Text className='font-Circular400 text-[11px] text-cheddr-page-bg tracking-[0.05em]'>{timeAgo}</Text></View>
                    </View>
                </View>
                <View className='flex-row gap-3'>
                    <View><Text className='font-Circular400 text-[#606060] text-[11px] tracking-[0.05em]'>NBA</Text></View>
                    <View><Text className='font-Circular400 text-[#606060] text-[11px] tracking-[0.05em]'>MONEYLINE</Text></View>
                </View>
            </View>
            <View className='flex-row items-center justify-between mb-2.5'>
                <View><Text className='font-Circular500 text-[28px] text-cheddr-white'>{team}</Text></View>
                <View><Text className='font-Circular500 text-[28px] text-cheddr-white'>{odds}</Text></View>
            </View>
            <View><Text className='font-Circular400 text-[16px] text-[#606060]'>{matchup}</Text></View>
        </View>

        <View className='w-full flex-row border-y border-[#525252]'>
            <View className='flex-1 items-center p-5 border-r border-[#525252]'>
                <View>
                    <View className='flex-row'>
                        <View><Text className='text-[#606060] font-Circular400 text-[16px]'>Risk</Text></View>
                        <View className='ml-[12px] mr-[10px]'><Image style={{width:22, height:22}} contentFit="contain" source={coinImage} /></View>
                        <View><Text className='text-cheddr-white font-Circular400 text-[16px]'>{risk}</Text></View>
                    </View>
                </View>
            </View>
            <View className='flex-1 items-center p-5'>
                <View>
                    <View className='flex-row'>
                        <View><Text className='text-[#606060] font-Circular400 text-[16px]'>Payout</Text></View>
                        <View className='ml-[12px] mr-[10px]'><Image style={{width:22, height:22}} contentFit="contain" source={coinImage} /></View>
                        <View><Text className='text-cheddr-white font-Circular400 text-[16px]'>{payout}</Text></View>
                    </View>
                </View>
            </View>
        </View>

        <View className='w-full px-5 pt-[30px] pb-[14px]'>
            <View className='flex-row items-center gap-3 mb-2'>
                <View><Text className='text-[16px] text-[#606060] font-Circular400'>Pick ID</Text></View>
                <View><Text className='text-[16px] text-cheddr-white font-Circular400'>{pickId}</Text></View>
            </View>
            <View className='flex-row items-center justify-between gap-4'>
                <View className='flex-1'>
                    <Text className='text-[16px] leading-none text-[#606060] font-Circular400'>{date}</Text>
                </View>
                <View>
                    <View className='flex-row items-center w-[68px] h-[26px] justify-center gap-2 bg-[#1C1C1C] rounded-[5px]'>
                        <View><Image style={{width:12, height:12}} contentFit='contain' source={require('../../assets/images/copy.png')} /></View>
                        <View><Text className='font-Circular400 text-[11px] text-[#8E8E8E] tracking-[0.05em]'>COPY</Text></View>
                    </View>
                </View>
            </View>
        </View>


    </View>
  );
};

export default BetCard;
