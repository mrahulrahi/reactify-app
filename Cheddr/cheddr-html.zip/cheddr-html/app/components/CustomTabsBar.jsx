import React from "react";
import { View, Text, Pressable } from "react-native";
import { useTheme } from "../contexts/ThemeContext";

const CustomTabBar = ({ state, navigation }) => {
  const { theme } = useTheme();  

  return (
    <View className="relative">
      <View className="w-full h-0.5 bg-[#363636] absolute bottom-0 -z-0"></View>
      <View className="flex-row h-[70px] px-[15px] relative z-10">
        
        {state.routes.map((route, index) => {
          const isFocused = state.index === index;
          const activeColor = theme === "yellow" ? "text-cheddr-yellow border-cheddr-yellow" : "text-green-500 border-green-500";
          const inactiveColor = "text-[#4C4C4C] border-[#363636]";

          return (
            <Pressable
              key={route.key}
              onPress={() => navigation.navigate(route.name)}
              className={`flex-1 items-center justify-center border-b  ${
                isFocused ? activeColor : inactiveColor
              }`}
            >
              <Text className={`text-[19px] font-Circular400 ${isFocused ? activeColor : inactiveColor}`}>
                {route.name}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
};

export default CustomTabBar;
