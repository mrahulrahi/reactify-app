import { View, Image } from "react-native";
import { useTheme } from "../contexts/ThemeContext";

const IconWithDot = ({ icon, focused }) => {
  const { theme } = useTheme(); 

  return (
    <View className="items-center relative">
      <Image source={icon} style={{ width: 24, height: 24 }} resizeMode="contain" />
      {focused && (
        <View className="absolute bottom-[-12px] left-[9px]" 
          style={{
            width: 6,
            height: 6,
            borderRadius: 3,
            backgroundColor: theme === "yellow" ? "#FFD93F" : "#4CAF50", 
            marginTop: 4,
          }}
        />
      )}
    </View>
  );
};

export default IconWithDot;
